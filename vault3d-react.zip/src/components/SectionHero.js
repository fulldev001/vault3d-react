import React from 'react';

export default function SectionHero({ children }) {
  // return <div className="bg-hero-background bg-cover">{children}</div>;
  return <div>{children}</div>;
};
