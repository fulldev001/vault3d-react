export const AppConfig = {
  site_name: 'VAULT3D',
  title: 'VAULT3D',
  description: 'Exclusive NFT Marketplace With Groundbreaking Features',
  locale: 'en',
};
